<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template 8</title>
    <link rel="stylesheet" href="{{ public_path('css/templates/premium/template-8.css') }}">
</head>
<body>
        <div class="">
                <div class="pad-1">
                    <h1 class="f-50 mb0">LYSANDRA VEGA</h1>
                    <p class="f-35 mt0 txt-clr">Software Engineer</p>
                </div>    
        </div>
        <div>
            <div class="pad-1 ">
                <div class="wid-40">
                    {{-- <img src="./images/5.png" alt=""> --}}
                        <span class="ft mb0 mt0">lysandrav@email.com</span>
                </div>
                <div class="wid-30-1">
                    {{-- <img src="./images/3.png" alt=""> --}}
                        <span class="ft mb0 mt0">(123) 456-7890	</span>
                </div>
                <div class="wid-30-1">
                    {{-- <img src="./images/1.png" alt=""> --}}
                        <span class="ft mb0 mt0">Indianapolis, IN </span>
                </div><div class="wid-100">
                    {{-- <img src="./images/4.png" alt=""> --}}
                        <span class="ft mb0 mt0" style="color: blue;"><u style="color: blue;">LinkedIn</u></span>
                </div>
                
            </div>
        </div>
        <div>
            <div class="wid-70">
                <div class="pad-1">
                    <h1 class="mb0">CAREER OBJECTIVE</h1>
                    <hr>
                    <p>New computer engineering graduate with strong problem- solving skills and a commitment to excellence, seeking a software engineer role at Salesforce. Excited to use my skill in Git and Python to support Salesforce's vision of helping companies connect with their customers in fresh ways. </p>
                    <h1 class="mb0">WORK EXPERIENCE</h1>
                    <hr>
                    <p class="fw-t ">Software Engineer Intern</p>
                    <p class="txt-clr fw-t">Infosys</p>
                    <div class="wid-40 f-left ">
                        {{-- <img src="./images/2.png" alt=""> --}}
                        <span class="ft mb0 mt0">January 2022 - March 2023</span>
            
                    </div>
                    <div class="wid-60 f-left  tc">
                        {{-- <img src="./images/1.png" alt=""> --}}
                        <span class="ft mb0 mt0">Indianapolis, IN </span>
            
                    </div>
                    <ul>
                        <li>DevelopUsed Visual Studio Code for effective code editing and debugging,<u><b>increasing code quality by 18%.</b></u>
                        </li>
                        <li>Integrated third-party APIs with Python to enhance app functionality and increase user satisfaction by 24%.</li>
                        <li>Improved database performance by optimizing MySQL queries, boosting query response times by 11%.</li>
                        <li>Streamlined the continuous integration and deployment (CI/CD) pipeline, reducing build times by 27%.</li>
                        <li>Cut merge conﬂicts by 13% using Git for version control and collaboration.</li>
                    </ul>
                    <h1 class="mb0">PROJECTS </h1>
                    <hr>
                    <p class="fw-t ">Academic Simulation Project</p>
                    <p class="txt-clr fw-t">Group Leader</p>
                    <div class="wid-100 f-left ">
                        {{-- <img src="./images/2.png" alt=""> --}}
                        <span class="ft mb0 mt0">2019 - current</span>
            
                    </div>
                    <ul>
                        <li>Developed backup and recovery strategies for macOS,<u><b>increasing data recovery speeds by 17%.</b></u>
                        </li>
                        <li>Implemented efﬁcient MySQL database schemas and decreased data redundancy by 28%.</li>
                        <li>Employed Django ORM to manage database interactions, streamlining and reducing development time by 19%.</li>
                        <li>Collaborated with a team of 4 to ensure timely project delivery while adhering to best practices.</li>
                    </ul>              
                </div>
            </div>
            <div class="wid-30">
                <div class="pad-2">
                    <h1 class="mb0">EDUCATION</h1>
                    <hr>
                    <p class="mb0">B.S.</p>
                    <p class="mb0 mt0">Computer Science </p>
                    <p class="fw-t txt-clr mt0">Purdue University</p>
                    <div>
                        {{-- <img src="./images/2.png" alt=""> --}}
                        <span>September 2019 - April 2023 </span>
                    </div>
                    <div>
                        {{-- <img src="./images/1.png" alt=""> --}}
                        <span> West Lafayette, IN</span>
                    </div>
                    <h1 class="mb0">SKILLS</h1>
                    <hr>
                    <ul>
                        <li>Visual Studio Code </li>
                        <li>Git </li>
                        <li>MySQL</li>
                        <li>Django  </li>
                        <li>Heroku </li>
                        <li>macOS </li>
                        <li>Python</li>
                    </ul>
                    <h1 class="mb0">CERTIFICATIONS</h1>
                    <hr>
                    <ul>
                        <li>Certiﬁed Software Development Professional (CSDP)</li>
                    </ul>
                </div>
            </div>
            </div>
        </body>
        </html>




































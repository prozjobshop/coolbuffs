<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template 10</title>
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="{{ public_path('css/templates/premium/template-10.css') }}">
    <link rel="stylesheet" href="../css/font-awesome.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../fonts/fontawesome-webfont.svg">
</head>
<body>

    <div class="pad-1" style="padding-top: 12px">
        @isset($user->name)
        <h1 class="f-50 mb0" style="font-size: 24px">{{ $user->name }}</h1>
        @endisset
        <p class="f-35 mt5 txt-clr">@isset($user_meta->career_level){{ $user_meta->career_level }}@endisset</p>
    </div>    

        <div>
            <div class="pad-1 ">
                @isset($user->email)
                <div class="wid-40">
                    <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC;" class="fa tc">&#xf0e0;</i>
                    <span class="ft mb0 mt0">{{ $user->email }}</span>
                </div> 
                @endisset
                @isset($user->mobile_num)
                <div class="wid-30-1">
                    <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC; font-size: 20px;" class="fa tc">&#xf095;</i>
                    <span class="ft mb0 mt0">{{ $user->mobile_num }}	</span>
                </div>
                @endisset
                @if(isset($user->country) || isset($user->state) || isset($user->city))
                <div class="wid-20">
                    <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC; font-size: 22px;" class="fa tc">&#xf041;</i>
                    <span class="ft2 mb0 mt0">{{ $user->city . ', ' . $user->state . ', ' . $user->country }}</span>
                </div>
                @endisset
            </div>
        </div>
        <div>
            <div class="wid-70">
                
        @if(
            isset($user->father_name) || 
            isset($user->date_of_birth) || 
            isset($user->gender_id) ||
            isset($user->marital_status_id) ||
            isset($user->nationality_id) ||
            isset($user->national_id_card_number) ||
            isset($user->phone) ||
            isset($user->job_experience) ||
            isset($user->industry) ||
            isset($user->functional_area) ||
            isset($user->current_salary) ||
            isset($user->expected_salary) ||
            isset($user->salary_currency) ||
            isset($user->street_address) ||
            isset($user->video_link)
            )
          <div class="experiences personal_details pad-1">
              <h1 class="mb0 f-20">PERSONAL DETAILS</h1>
              <hr class="mt0">
  
  
              @isset($user->father_name)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">Father Name :</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->father_name }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->date_of_birth)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">Date of Birth :</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ date('d F, Y', strtotime($user->date_of_birth)) }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->gender_id)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">Gender</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->gender }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->marital_status)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Marital Status : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->marital_status }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->nationality)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Nationality : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->nationality }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->national_id_card_number)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'National ID : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->national_id_card_number }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->phone)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Phone : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->phone }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->job_experience)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Job Experience : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->job_experience }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->industry)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Industry : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->industry }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->functional_area)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Functional Area : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->functional_area }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->current_salary)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Current Salary : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->current_salary }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->expected_salary)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Expected Salary : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->expected_salary }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->salary_currency)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Salary Currency : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->salary_currency }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->street_address)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Street Address : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->street_address }}</span>
                  </div>
                </div>
              @endisset
              @isset($user->video_link)
                <div class="experience">
                  <div class="wid-50 f-left  test-borde">
                    <span class="f-14 mb0 mt0">{{ 'Video Profile : ' }}</span>
                  </div>
  
                  <div class="wid-50 f-left tc test-borde">
                    <span class="f-14 mb0 mt0">{{ $user->video_link }}</span>
                  </div>
                </div>
              @endisset
          </div>
          @endif
  


                <div class="pad-1">
                    @if(!empty($user->getProfileSummary('summary')))
                    <h1 class="mb0">CAREER OBJECTIVE</h1>
                    <hr style="margin-top: 1px">
                    <p style="margin-top: 2px">{{$user->getProfileSummary('summary')}} </p>
                    @endif

                    @if(count($user_experience) > 0)
                    <h1 class="mb0">WORK EXPERIENCE</h1>
                    <hr style="margin-top: 1px">
                    @foreach($user_experience as $user_exp)
                    <p class="fw-t" style="margin-top: -8px">{{ $user_exp->title }}</p>
                    <p class="txt-clr fw-t" style="padding-top: -18px">{{ $user_exp->company }}</p>
                    <div class="wid-40 f-left " style="margin-top: -18px">
                      <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC;" class="fa tc">&#xf073;</i>
                        <span class="ft mb0 mt0" style="font-size: 11px">{{ date('M, Y', strtotime($user_exp->date_start)) . ' - ' . date('M, Y', strtotime($user_exp->date_end)) }}</span>
            
                    </div>
                    <div class="wid-60 f-left  tc" style="margin-top: -1px">
                        <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC; font-size: 22px;" class="fa tc">&#xf041;</i>
                        <span class="ft mb0 mt0">{{ $user_exp->city_name }} </span>
            
                    </div>
                    <ul style="margin-top: 0.5px">
                        <li class="ft1">{{$user_exp->description}}</li>
                        {{-- <li class="ft1">Improved database performance by optimizing MySQL queries, boosting query response times by 11%.</li>
                        <li class="ft1">Streamlined the continuous integration and deployment (CI/CD) pipeline, reducing build times by 27%.</li>
                        <li class="ft1">Cut merge conﬂicts by 13% using Git for version control and collaboration.</li> --}}
                    </ul>
                    @endforeach
                    @endif
                    @if(count($user_projects) > 0)
                    <h1 class="mb0">PROJECTS </h1>
                    <hr style="margin-top: 1px">
                    @foreach($user_projects as $project)
                    <p class="fw-t " style="margin-top: 2px">{{ $project->name }}</p>
                    <p class="txt-clr fw-t" style="padding-top: -18px">{{ $project->url }}</p>
                    <div class="wid-100 f-left "  style="margin-top: -18px">
                        <i class="fa fa-2x fa-calendar" style="color: #CCCCCC;"></i>
                        <span class="ft mb0 mt0">{{ date('M, Y', strtotime($project->date_start)) . ' - ' . date('M, Y', strtotime($project->date_end)) }}</span>
            
                    </div>
                    <ul>
                        <li class="ft1">{{$project->description}}</li>
                        {{-- <li class="ft1">Employed Django ORM to manage database interactions, streamlining and reducing development time by 19%.</li>
                        <li class="ft1">Collaborated with a team of 4 to ensure timely project delivery while adhering to best practices.</li> --}}
                    </ul>   
                    @endforeach           
                </div>
                @endif
            </div>
            <div class="wid-30">
                <div class="pad-2">
                    @if(count($user_educations) > 0)
                    <h1 class="mb0">EDUCATION</h1>
                    <hr style="margin-top: 1px">
                    @foreach($user_educations as $user_edu)
                    <p class="mb0" style="margin-top: -3px">{{ $user_edu->degree_level }}</p>
                    <p class="mb0 mt0">{{ $user_edu->degree_type }}</p>
                    <p class="fw-t  txt-clr" style="padding-top: -18px;">{{ $user_edu->institution }}</p>
                    <div style="padding-top: -18px;">
                        <i class="fa fa-2x fa-calendar" style="color: #CCCCCC;"></i>
                        <span class="ft" style="font-size: 10px; padding-top:-16px">{{ $user_edu->date_completion }} </span>
                    </div>
                    <div>
                         <i class="fa fa-2x fa-location-arrow" style="color: #CCCCCC;"></i>
                        <span class="ft" style="font-size: 12px"> {{ $user_edu->city }}</span>
                    </div>
                    @endforeach
                    @endif
                    @if(count($user_skills) > 0)
                    <h1 class="mb0">SKILLS</h1>
                    <hr style="margin-top: 1px">
                    <ul style="margin-top: -8px">
                        @foreach($user_skills as $user_skill)
                        <li class="ft1">{{ $user_skill->job_skill}} - <span class="ft1 f-b txt-clr">{{ $user_skill->job_experience}}</span></li>                        <li class="ft1">Git </li>
                        {{-- <li class="ft1">MySQL</li>
                        <li class="ft1">Django  </li>
                        <li class="ft1">Heroku </li>
                        <li class="ft1">macOS </li>
                        <li class="ft1">Python</li> --}}
                        @endforeach
                    </ul>
                    @endif


                    @if(count($user_languages) > 0)
                    <h1 class="mb0">LANGUAGES</h1>
                    <hr style="margin-top: 1px">
                    <ul>
                        @foreach($user_languages as $user_language)
                        <li class="ft1">{{ $user_language->lang }}</li>
                    @endforeach
                    </ul>
                </div>
                @endif
            </div>
            </div>
        </body>
        </html>




































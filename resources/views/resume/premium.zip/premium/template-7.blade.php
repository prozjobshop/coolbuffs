<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template 8</title>
    <link rel="stylesheet" href="{{ public_path('css/templates/premium/template-7.css') }}">

<body>
  <div>
      <div class="wid-35">

          <div class="bg">

            <div class="pad-3">
              @isset($user->name)
                <h1 class="mb0 tw mt0" style="font-size: 26px;">{{ $user->first_name . ' ' . $user->middle_name . ' ' . $user->last_name }}</h1>
              @endisset

              <h3 class="tw"><i>@isset($user_meta->career_level){{ $user_meta->career_level }}@endisset</i></h3>

              @isset($user->email)
              <div>
                  <i class="fa fa-2x fa-envelope-o" style="color: #CCCCCC;"></i>
                      <span class="mb0 mt0 tw mb5">
                        <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC;" class="fa tc">&#xf0e0;</i>
                        <span class="f-b">&nbsp;{{ $user->email }}</span>
                      </span>
              </div>
              @endisset
              @isset($user->mobile_num)
              <div>
                  <i class="fa fa-2x fa-phone" style="color: #CCCCCC;"></i>
                      <span class="mb0 mt0 tw mb5">
                        <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC; font-size: 20px;" class="fa tc">&#xf095;</i>
                        <span class="f-b">&nbsp;{{ $user->mobile_num }}</span>
                      </span>
              </div>
              @endisset
              @if(isset($user->country) || isset($user->state) || isset($user->city))
              <div>
                  <i class="fa fa-2x fa-location-arrow" style="color: #CCCCCC;"></i>
                      <span class="mb0 mt0 tw mb5">
                        <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC; font-size: 22px;" class="fa tc">&#xf041;</i>
                        <span class="f-b">&nbsp;{{ $user->city . ', ' . $user->state . ', ' . $user->country }}</span>
                      </span>
              </div>
              @endif
            </div>

            <div class="bg-1">
              <div class="pad-3">

                @if(count($user_educations) > 0)
                <div class="educations">
                  <h1 class="mb0 mt0 ">EDUCATION</h1>

                  @foreach($user_educations as $user_edu)
                  <div class="education sections-mtb">
                    <p class="mb0 mt0">{{ $user_edu->degree_level }}</p>
                    <p class="mb0 mt0">{{ $user_edu->degree_type }}</p>
                    <p class="m-5 f-b">{{ $user_edu->institution }}</p>
                    <div>
                        <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC;" class="fa tc">&#xf073;</i>
                        <span>{{ $user_edu->date_completion }}</span>
                    </div>
                    <div>
                      <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC; font-size: 22px;" class="fa tc">&#xf041;</i>
                      <span>{{ $user_edu->city }}</span>
                    </div>
                  </div>
                  @endforeach

                </div>
                @endif


                @if(count($user_skills) > 0)
                <div class="skills">
                  <h1 class="sections-mtb">SKILLS</h1>
                  
                  <ul>
                    @foreach($user_skills as $user_skill)
                      <li>{{ $user_skill->job_skill}}</li>
                    @endforeach
                  </ul>
                </div>
                @endif


                {{-- <div class="hobbies">
                  <h1 class="mb0">HOBBIES</h1>
                  <ul>
                      <li>Food Photography </li>
                      <li>Travel Photography</li>
                      <li>Video editing and post- production</li>
                  </ul>
                </div> --}}


                @if(count($user_languages) > 0)
                <div class="languages">
                  <h1 class="mb0">LANGUAGES</h1>
                  <ul>
                    @foreach($user_languages as $user_language)
                      <li>{{ $user_language->lang }}</li>
                    @endforeach
                  </ul>
                </div>
                @endif
                
              </div>

              <div class="extra_spacing">&nbsp;</div>
            </div>

            

          </div>

      </div>


      <div class="wid-65">
          <div class="pad-1">

              @if($user->getProfileSummary('summary'))
              <div class="about">
                <h1 class="mb0">CAREER OBJECTIVE</h1>
                <p>{{$user->getProfileSummary('summary')}}</p>
              </div>
              @endif

              @if(
                isset($user->father_name) || 
                isset($user->date_of_birth) || 
                isset($user->gender_id) ||
                isset($user->marital_status_id) ||
                isset($user->nationality_id) ||
                isset($user->national_id_card_number) ||
                isset($user->phone) ||
                isset($user->job_experience) ||
                isset($user->industry) ||
                isset($user->functional_area) ||
                isset($user->current_salary) ||
                isset($user->expected_salary) ||
                isset($user->salary_currency) ||
                isset($user->street_address) ||
                isset($user->video_link)
                )
              {{-- Personal Details --}}
              <div class="personal_details">
                <h1 class="sections-mb mb0">PERSONAL DETAILS</h1>

                @isset($user->father_name)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Father Name
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->father_name }}
                  </div>
                </div>
                @endisset
                @isset($user->date_of_birth)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Date of Birth
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ date('d F, Y', strtotime($user->date_of_birth)) }}
                  </div>
                </div>
                @endisset
                @isset($user->gender_id)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Gender
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->gender }}
                  </div>
                </div>
                @endisset
                @isset($user->marital_status)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Marital Status
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->marital_status }}
                  </div>
                </div>
                @endisset
                @isset($user->nationality)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Nationality
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->nationality }}
                  </div>
                </div>
                @endisset
                @isset($user->national_id_card_number)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    National ID
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->national_id_card_number }}
                  </div>
                </div>
                @endisset
                @isset($user->phone)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Phone
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->phone }}
                  </div>
                </div>
                @endisset
                @isset($user->job_experience)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Job Experience
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->job_experience }}
                  </div>
                </div>
                @endisset
                @isset($user->industry)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Industry
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->industry }}
                  </div>
                </div>
                @endisset
                @isset($user->functional_area)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Functional Area
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->functional_area }}
                  </div>
                </div>
                @endisset
                @isset($user->current_salary)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Current Salary
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->current_salary }}
                  </div>
                </div>
                @endisset
                @isset($user->expected_salary)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Expected Salary
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->expected_salary }}
                  </div>
                </div>
                @endisset
                @isset($user->salary_currency)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Salary Currency
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->salary_currency }}
                  </div>
                </div>
                @endisset
                @isset($user->street_address)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Street Address
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->street_address }}
                  </div>
                </div>
                @endisset
                @isset($user->video_link)
                <div class="personal_detail">
                  <div class="wid-60 f-left ">
                    Video Profile
                  </div>
                  <div class="wid-40 f-left  tc">
                    {{ $user->video_link }}
                  </div>
                </div>
                @endisset

              </div>
              @endif


              @if(count($user_experience) > 0)
              <div class="experiences">
                <h1 class="sections-mb mb0">WORK EXPERIENCE</h1>

                @foreach($user_experience as $user_exp)
                <div class="experience">
                  <p class="m-5 f-16">{{ $user_exp->title }}</p>

                  <p class="w-t m-5 f-b">{{ $user_exp->company }}</p>
                  <div class="wid-60 f-left ">
                      <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC;" class="fa tc">&#xf073;</i>
                      <span class="ft mb0 mt0">{{ date('M, Y', strtotime($user_exp->date_start)) . ' - ' . date('M, Y', strtotime($user_exp->date_end)) }}</span>
          
                  </div>
                  <div class="wid-40 f-left  tc">
                      <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC; font-size: 22px;" class="fa tc">&#xf041;</i>
                      <span class="ft mb0 mt0">{{ $user_exp->city_name }}</span>
                  </div>
                  <p class="mb0 mt0" style="padding: 10px 15px;">
                    {{$user_exp->description}}
                  </p>
                </div>
                @endforeach
              </div>
              @endif


              @if(count($user_projects) > 0)
              <div class="projects">
                <h1 class="sections-mb mb0">PROJECTS</h1>

                @foreach($user_projects as $project)
                <div class="project">
                  <p class="m-5 f-16">{{ $project->name }}</p>

                  <p class="m-5 f-b f-12">{{ $project->url }}</p>
                  <div class="wid-60 f-left">
                      <i style="font-family: fontawesome; font-style: normal;color: #CCCCCC;" class="fa tc">&#xf073;</i>
                      <span class="ft mb0 mt0">{{ date('M, Y', strtotime($project->date_start)) . ' - ' . date('M, Y', strtotime($project->date_end)) }}</span>
          
                  </div>
                  <div class="clear"></div>
                  <p class="mb0 mt0" style="padding: 10px 15px;">
                    {{$project->description}}
                  </p>
                </div>
                @endforeach          
              </div>
              @endif


              {{-- <div class="certifications">
                <h1 class="sections-mb mb0">CERTIFICATIONS</h1>

                <ul>
                  <li>Microsoft Certiﬁed: Azure Developer Associate</li>
                  <li>Oracle Certiﬁed Professional: Java SE 11 Developer</li>
                </ul> 
              </div> --}}


          </div>
      </div>
  </div>
</body>
</html>